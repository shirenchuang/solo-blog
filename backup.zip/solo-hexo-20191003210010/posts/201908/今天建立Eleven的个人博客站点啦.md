title: 今天建立Eleven的个人博客站点啦
date: '2019-08-14 23:02:47'
updated: '2019-08-14 23:02:47'
tags: [生活]
permalink: /articles/2019/08/14/1565794967222.html
---
![](https://img.hacpai.com/bing/20190116.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 个人博客今天建站

第一天, 今天建立自己的个人博客站点啦;
Eleven,一定要坚持写博客哦!
提示自身能力
为了未来不被淘汰
**请保持学习的激情**
