title: 【Nacos源码之配置管理 五】为什么把配置文件Dump到磁盘中
date: '2019-09-06 13:43:31'
updated: '2019-09-06 13:43:31'
tags: [nacos, 源码解析]
permalink: /articles/2019/09/06/1567748611660.html
---
<font face="黑体" color=green size=2>版权声明：本文为博主原创文章，遵循[CC 4.0 by-sa](http://creativecommons.org/licenses/by-sa/4.0/)
版权协议，转载请附上原文出处链接和本声明。 
本文链接: [http://blog.shiyi.online/articles/2019/09/06/1567738669800.html](http://blog.shiyi.online/articles/2019/09/06/1567738669800.html)
首发地址:[https://mp.weixin.qq.com/s/ye1u4b_eWjpO5etwp60hVg](https://mp.weixin.qq.com/s/ye1u4b_eWjpO5etwp60hVg)
</font>



# 前言
上一篇文章 [【Nacos源码之配置管理 四】DumpService如何将配置文件全部Dump到磁盘中](https://shirenchuang.blog.csdn.net/article/details/100098374) 分析了Nacos将配置文件Dump的磁盘中,那我为什么要Dump到磁盘中呢？这样做有什么好处？哪些地方读取了磁盘中的文件？带着这些问题,我们去源码中一探究竟;

## 1.快速启动,将数据库中的数据与磁盘对比MD5判断是否修改
```java

//  Dump 修改过的配置文件
 static public boolean dumpChange(String dataId, String group, String tenant, String content, long lastModifiedTs) {
        //省略....
            final String md5 = MD5.getInstance().getMD5String(content);
            if (!STANDALONE_MODE || PropertyUtil.isStandaloneUseMysql()) {
                 /**读取本地磁盘文件的MD5**/
                String loacalMd5 = DiskUtil.getLocalConfigMd5(dataId, group, tenant);
                if (md5.equals(loacalMd5)) {
                    dumpLog.warn(
                        "[dump-ignore] ignore to save cache file. groupKey={}, md5={}, lastModifiedOld={}, "
                            + "lastModifiedNew={}",
                        groupKey, md5, ConfigService.getLastModifiedTs(groupKey), lastModifiedTs);
                } else {
                    DiskUtil.saveToDisk(dataId, group, tenant, content);
                }
            }
    }

```


## 2. 同步配置获取接口ConfigServletInner.doGetConfig

这是一个Http请求调用的接口,这是获取配置数据的接口,最终是调用了 `DiskUtil.targetFile(dataId, group, tenant);` 方法得到配置文件; 然后把文件中的信息返回到Response中给请求方; 

注意: 配置中心的内存是没有保存配置信息content的；因为content一般数据都不小;全部存放到内存中,对Jvm的内存占用比较大,所以内存只保存了基本信息；content具体内容保存在磁盘中; 等客户端发起Http请求获取对应配置信息的时候,再去磁盘中读取返回给客户端;  读取磁盘文件肯定是比读取数据库效率要高高的;


### 为什么要把配置文件Dump到磁盘中
Dump配置文件到磁盘中可以提高性能; 客户端想要请求配置数据的时候,发起Http请求给服务端; 服务端会去磁盘中读取对应文件返回; 读取磁盘文件比直接读取数据库效率要高;
然后服务端会跟最新的数据会保持一致,如果修改了配置，不仅Jvm内存数据会更新,也会把最新的content内容及时保存到磁盘文件中;


