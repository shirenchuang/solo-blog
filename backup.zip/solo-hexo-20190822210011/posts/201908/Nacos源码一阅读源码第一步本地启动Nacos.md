title: 【Nacos源码 一】阅读源码第一步,本地启动Nacos
date: '2019-08-20 16:19:42'
updated: '2019-08-21 10:21:18'
tags: [nacos, 源码解析]
permalink: /articles/2019/08/20/1566289182119.html
---
![](https://img.hacpai.com/bing/20180403.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言

在我们去阅读Nacos源码之前,我们得先了解Nacos是干嘛的,以及怎么用,这样有利于我们更容易去理解源码;

查看Nacos的官方文档,我们知道Naocs主要有一下特性:

- **配置中心**
- **服务注册与发现**
- **...**

Nacos有给我们提供管理界面,用来方便配置数据;我们先把整个Nacos源码克隆下来,本地启动;熟悉一下如何使用它

## 启动Nacos项目

### 1.克隆Nacos源码
```
git clone https://github.com/alibaba/nacos.git 

```
导入到Idea中
![image.png](https://img.hacpai.com/file/2019/08/image-73d962f2.png)

### 2.配置Mysql数据源
Nacos内置嵌入式derby数据库,但是它只适合开发测试中使用,也不利于我们观察数据;所以我们更改一下数据库为Mysql

在使用Mysql之前,需要先建立nacos_config的数据库sql文件在模块 `distribution` 中的`conf/nacos-mysql.sql` ; 执行一下这个文件;



在模块  `nacos/distribution` 中添加Mysql的配置文件
```xml
## 数据库为mysql
spring.datasource.platform=mysql
## 数据库编号 因为可能配置有多数据源 主从
db.num=1
db.url.0=jdbc:mysql://XX.XX.XXX.XX:3306/nacos_config?characterEncoding=utf8&connectTimeout=1000&socketTimeout=3000&autoReconnect=true
db.user.0=name
db.password.0=password
```

![image.png](https://img.hacpai.com/file/2019/08/image-01a6229e.png)


### 3.将项目打包发布

执行打包命令
```
mvn -Prelease-nacos clean install -U  -Dmaven.test.skip=true
```
![image.png](https://img.hacpai.com/file/2019/08/image-621beba5.png)


打包完毕,执行启动脚本
```
sh distribution/target/nacos-server-{version}/nacos/bin/startup.sh -m standalone
```
![image.png](https://img.hacpai.com/file/2019/08/image-39381d11.png)

这里 `-m standalon`e 表示单机模式启动,还有其他可选的参数有:
- **-f  [config/naming]**  
***启动模式*** 支持只启动某一个模块，config:配置中心; naming:服务注册与发现，不设置时所有模块都会启动

- **-s**  后面接服务包名字; 默认值是 `nacos-server`
就是可以指定启动的Jar包名;
![image.png](https://img.hacpai.com/file/2019/08/image-b0a36f32.png)





### 检查启动是否成功

![image.png](https://img.hacpai.com/file/2019/08/image-1092f12b.png)
启动成功之后,就可以访问管理后台了
[http://localhost:8848/nacos/index.html](http://localhost:8848/nacos/index.html)   登陆账户密码都是:   **nacos**
登陆之后的管理后台
![image.png](https://img.hacpai.com/file/2019/08/image-3cea2522.png)

如果刚刚启动的时候加了参数  `-f config` 那么现在看到的只有**配置管理**和**命名空间**两个菜单栏了
使用的详细解释可以参考官方文档 **[控制台手册](https://nacos.io/zh-cn/docs/console-guide.html)**

## Nacos配置中心数据库表结构说明

### tenant_info 租户信息表(命名空间表)

Nacos 基于Namespace 帮助用户逻辑隔离多个命名空间，这可以帮助用户更好的管理测试、预发、生产等多环境服务和配置，让每个环境的同一个配置（如数据库数据源）可以定义不同的值。
![image.png | left | 747x206](https://cdn.nlark.com/lark/0/2018/png/9687/1540519427066-effd5153-02c9-4e21-ae9f-1a2e9ae7713e.png)

这个命名空间的数据就是存在表 `tenant_info` 中
**tenant_info**

|字段|备注|
|----|----|
|id|主键自增|
|kp|(Todo...)定值1|
|tenant_id|命名空间id,是一个UUID字符串|
|tenant_name|命名空间名字|
|tenant_desc|命名空间描述|
|create_source|创建人|
|gmt_create|创建时间|
|gmt_modified|修改时间|

**<font color=red>(`kp`,`tenant_id`) 组成唯一约束</font>**

### config_info 配置信息表
> 所有配置的数据都存在这个表中;

|字段|描述|
|---|---|
|id|自增主键|
|data_id|数据ID|

**<font color="red"> TODO.....</font>**

## 如何本地调试Jar包方式启动的源码

由于上面的启动方式,我们可能不能进行本地Debug;但是我们可以在启动的时候开启Debug端口,通过远程监听Debug端口来进行Debug;

那么我们先修改一下启动脚本,打开调试端口修改
文件 <font color="red">  `  distribution/target/nacos-server-{version}/nacos/bin/startup.sh ` </font>

```java

# 加入调试端口  6666调试端口随意设置
JAVA_DEBUG_OPTS="-Xdebug -Xnoagent -Djava.compiler=NONE -Xrunjdwp:transport=dt_socket,address=6666,server=y,suspend=n"
echo "$JAVA ${JAVA_DEBUG_OPTS} ${JAVA_OPT}  " > ${BASE_DIR}/logs/start.out 2>&1 &
nohup $JAVA ${JAVA_DEBUG_OPTS} ${JAVA_OPT}  nacos.nacos >> ${BASE_DIR}/logs/start.out 2>&1 &

```
![image.png](https://img.hacpai.com/file/2019/08/image-529bfe0c.png)

**重新启动**

先把项目停止
`sh distribution/target/nacos-server-{version}/nacos/bin/shutdown.sh` 
然后重新启动
`sh distribution/target/nacos-server-1.1.3/nacos/bin/startup.sh -m standalone`

启动成功,检查调试端口是否打开
![image.png](https://img.hacpai.com/file/2019/08/image-f9bdf672.png)
已经有一个6666的端口在LISTEN中了;

**配置调试**
在Idea中新建一个remote启动;
![image.png](https://img.hacpai.com/file/2019/08/image-86f8d935.png)
![image.png](https://img.hacpai.com/file/2019/08/image-9a13ad06.png)

**启动调试**
启动调试; 打一个断点,然后管理后端操作一下;看下效果
![image.png](https://img.hacpai.com/file/2019/08/image-5d8e1e4b.png)

**调试成功**


项目启动了,也调试成功了; 那么我们就可以方便的开始阅读源码了！










