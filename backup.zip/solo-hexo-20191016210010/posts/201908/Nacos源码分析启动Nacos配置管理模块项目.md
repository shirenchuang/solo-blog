title: 【Nacos源码分析】 启动Nacos配置管理模块项目
date: '2019-08-15 18:58:51'
updated: '2019-09-06 11:16:52'
tags: [nacos, 源码解析]
permalink: /articles/2019/08/15/1565866731149.html
---
<font face="黑体" color=green size=2>
版权声明：本文为博主原创文章，遵循[CC 4.0 by-sa](http://creativecommons.org/licenses/by-sa/4.0/)
版权协议，转载请附上原文出处链接和本声明。 
本文链接: [http://blog.shiyi.online/articles/2019/08/15/1565866731149.html](http://blog.shiyi.online/articles/2019/08/15/1565866731149.html)
</font>

**本节我们主要分析 配置管理 的章节**

# 拉取Nacos源码

用Idea或者git clone拉取Nacos源码;源码地址

```
git clone https://github.com/alibaba/nacos.git 
```
# 启动配置管理模块项目

源码中有很多模块,其他的我们先不看,主要看 ```nacos-config```模块,这个模块是配置管理相关的项目;

这是一个Spring-Boot项目,我们找到启动类 ``` Config ```运行;
结果会发现报错:
```
java.io.IOException: java.lang.IllegalArgumentException: db.num is null
	at com.alibaba.nacos.config.server.service.BasicDataSourceServiceImpl.reload(BasicDataSourceServiceImpl.java:217)
	at com.alibaba.nacos.config.server.service.BasicDataSourceServiceImpl.init(BasicDataSourceServiceImpl.java:131)
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
```
分析启动源码得知,错误的原因是没有数据库,但是没有配置数据库;所以我们得先配置数据库;

## 单机模式使用Derby嵌入式数据库
 
Nacos单机模式默认是用内置了嵌入式数据库Derby做存储的;

```
/*如果是单机模式,并且不使用Mysql; 这个propertyUtil.isStandaloneUseMysql()只有在配置了属性 
spring.datasource.platform=mysql 才会去初始化Mysql数据源
*/
if (STANDALONE_MODE && !propertyUtil.isStandaloneUseMysql()) {
            dataSourceService = (DataSourceService)applicationContext.getBean("localDataSourceService");
        } else {
            dataSourceService = (DataSourceService)applicationContext.getBean("basicDataSourceService");
        }
```
**想要切换成mysql 配置一下**

```
spring.datasource.platform=mysql
```

因为模式不是单机模式,所有我们启动的时候要配置单机模式启动; 
我们在启动的时候加上JVM属性 ``` -Dnacos.standalone=true ```;就可以了;
关于Jvm属性配置,不懂的可以看这里  [Java -D设置系统属性讲解](http://blog.xiao2go.com/articles/2019/08/15/1565861655572.html)

**注意: Derby 数据库只有在Nacos是单机模式的时候才会使用,而且Nacos单机模式只可以在测试和学习的时候使用,不建议使用在生产环境中,生产环境的数据库是Mysql**


## 单机模式启动,使用Mysql数据库

在使用Mysql之前,需要先建立nacos_config的数据库sql文件在模块 ```distribution``` 中的```conf/nacos-mysql.sql``` ; 执行一下这个文件; 然后在模块 ```nacos-config/resources``` 下面新建一个配置文件 ```application.properties``` 里面配置一下数据库
```

# 数据源用 mysql
spring.datasource.platform=mysql
db.num=1
db.url.0=jdbc:mysql://XX.XX.XXX.XX:3306/nacos_config?characterEncoding=utf8&connectTimeout=1000&socketTimeout=3000&autoReconnect=true
db.user=user
db.password=password

```
启动,成功!

启动成功之后我们就可以配置数据和获取数据了,因为我们指启动了 ``` nacos-config``` 模块,所以是没有UI界面的; 通过接口来操作数据;

### 配置数据

```
curl -X POST "http://127.0.0.1:8848/nacos/v1/cs/configs?dataId=nacos.cfg.dataId&group=test&content=HelloWorld"
```

### 获取刚刚配置的数据

```
curl -X GET "http://127.0.0.1:8848/nacos/v1/cs/configs?dataId=nacos.cfg.dataId&group=test"

```


接下来,我们从分析一下``` nacos-config ``` 的源码





# 参考文章

[Nacos支持三种部署模式](https://nacos.io/zh-cn/docs/deployment.html)

 [Java -D设置系统属性讲解](http://blog.xiao2go.com/articles/2019/08/15/1565861655572.html)







