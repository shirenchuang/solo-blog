title: 【Nacos源码系列】Nacos 快速开始
date: '2019-08-15 13:58:43'
updated: '2019-08-15 19:43:13'
tags: [nacos, 源码解析]
permalink: /articles/2019/08/15/1565848723257.html
---
**查看官网的Nacos快速开始**  [快速开始](https://nacos.io/zh-cn/docs/quick-start.html)


启动命令(standalone代表着单机模式运行，非集群模式):

```sh startup.sh -m standalone```
这个时候可以打开后台配置界面了
http://localhost:8848/nacos
账户密码都是  : nacos

![image.png](https://img.hacpai.com/file/2019/08/image-4a952287.png)


---

[# Nacos Spring Boot 快速开始](https://nacos.io/zh-cn/docs/quick-start-spring-boot.html)

### TODO Know

* [ ]  Nacos的配置数据存储在哪里?
* [ ] Nacos启动的时候会将所有持久化数据加载吗?
* [ ] Nacos是如何自动更新数据的？

**接下来的文章,将围绕这些问题从源码层面去分析;**
